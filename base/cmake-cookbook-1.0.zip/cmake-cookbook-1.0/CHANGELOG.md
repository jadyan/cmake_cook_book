# Change Log


## [Unreleased]

### Added
### Changed
### Deprecated
### Removed
### Fixed
### Security


## [Version 1.0] - 2018-09-24


[Unreleased]: https://github.com/dev-cafe/cmake-cookbook/compare/v1.0...HEAD
[Version 1.0]: https://github.com/dev-cafe/cmake-cookbook/releases/tag/v1.0
