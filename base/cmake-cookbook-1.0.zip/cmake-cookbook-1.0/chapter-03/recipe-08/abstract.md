This recipe shows how to find the [Boost C++](https://www.boost.org/) libraries and how these are
conveniently wrapped into [`IMPORTED` libraries](https://cmake.org/cmake/help/latest/manual/cmake-buildsystem.7.html#imported-targets) in CMake.
