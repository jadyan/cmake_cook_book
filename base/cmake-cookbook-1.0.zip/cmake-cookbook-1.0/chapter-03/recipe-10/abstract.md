This recipe shows how to write a `FindZeroMQ.cmake` module to detect the ZeroMQ library.
