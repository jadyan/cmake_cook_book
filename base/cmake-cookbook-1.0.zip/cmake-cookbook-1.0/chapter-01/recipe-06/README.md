# Specifying the compiler

This recipe explains how to set the compiler for the project. We will discuss
the [`CMAKE_<LANG>_COMPILER`](https://cmake.org/cmake/help/latest/variable/CMAKE_LANG_COMPILER.html) CMake options.


- [example](example/)
