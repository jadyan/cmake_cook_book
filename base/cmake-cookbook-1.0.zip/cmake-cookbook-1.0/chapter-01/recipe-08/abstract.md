This recipe shows how to set compiler flags for targets using
[`target_compile_options()`](https://cmake.org/cmake/help/latest/command/target_compile_options.html). The compiler options set are only valid for GCC and
Clang, thus building this project **fails** on Visual Studio.
