We demonstrate how to build a set of source files into shared or static libraries.
An example is also given that demonstrates the use of the CMake [`OBJECT` library](https://cmake.org/cmake/help/latest/command/add_library.html#object-libraries)
facility to build _both_ the shared and static variant.
The latter example will be revisited in [Recipe 2 in Chapter 10](../../chapter-10/recipe-02/README.md)
