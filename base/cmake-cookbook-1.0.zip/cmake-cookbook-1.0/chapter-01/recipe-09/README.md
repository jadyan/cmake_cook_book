# Setting the standard for the language

We will show various mechanism to require and set a specific compiler standard
for our project.


- [cxx-example](cxx-example/)
- [fortran-example](fortran-example/)
