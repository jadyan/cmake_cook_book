#include "Dog.hpp"

std::string Dog::name_impl() const { return "I'm " + name_ + " the dog!"; }
