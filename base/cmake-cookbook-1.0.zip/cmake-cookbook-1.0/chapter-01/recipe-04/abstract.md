This recipe demonstrates how to use the [`if-else-endif`](https://cmake.org/cmake/help/latest/command/if.html) conditional construct in `CMakeLists.txt`.
