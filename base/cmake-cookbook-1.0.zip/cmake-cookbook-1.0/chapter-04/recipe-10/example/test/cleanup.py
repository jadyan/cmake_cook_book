import sys

print("tearing down")

# report success
sys.exit(0)
