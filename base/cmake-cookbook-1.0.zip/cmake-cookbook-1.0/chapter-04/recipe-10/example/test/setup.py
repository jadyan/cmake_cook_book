import sys

print("setting up")

# report success
sys.exit(0)
