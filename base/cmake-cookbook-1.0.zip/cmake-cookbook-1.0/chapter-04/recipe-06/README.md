# Testing expected failures

Ideally, we want all of our tests to always pass on every platform. However, we
may want to test whether an expected failure or exception will occur in a
controlled setting, and in that case, we would define the expected failure as a
successful outcome. In this recipe, we demonstrate such a situation.


- [example](example/)
