#pragma once

#include <vector>

int sum_integers(const std::vector<int> integers);
