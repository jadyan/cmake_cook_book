#pragma once

int do_some_work();
