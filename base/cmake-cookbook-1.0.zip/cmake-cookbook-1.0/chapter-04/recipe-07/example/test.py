import sys
import time

# wait for 2 seconds
time.sleep(2)

# report success
sys.exit(0)
