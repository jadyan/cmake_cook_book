# Running a subset of tests

In this recipe, we present strategies to only run a selected subset of tests,
either by their label, their name (regular expression), or their number.


- [example](example/)
