# Using platform-independent file operations

This recipe will show how to run operations on files, such as uncompressing a
archive or renaming a folder, in a platform-independent fashion.
CMake can in fact be used in [command-line tool mode](https://cmake.org/cmake/help/v3.12/manual/cmake.1.html#command-line-tool-mode)
and offers a number of wrappers to many common operations.


- [cxx-example](cxx-example/)
