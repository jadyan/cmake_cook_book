# Running a custom command at build time: I. Using `add_custom_command`

This recipe will show how to use [`add_custom_target`] to add new targets with
custom build goals to the build system.

[`add_custom_target`]: https://cmake.org/cmake/help/latest/command/add_custom_target.html


- [cxx-example](cxx-example/)
