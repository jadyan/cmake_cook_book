In this example, we generate C++ code
by using Python at build time.
