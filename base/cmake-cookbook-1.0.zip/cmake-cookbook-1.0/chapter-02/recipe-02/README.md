# Dealing with platform-dependent source code

Ideally, we should avoid platform-dependent source code, but sometimes we have
no choice. In this recipe, we demonstrate how to use CMake
to conditionally compile source code depending on the operating system.


- [cxx-example](cxx-example/)
