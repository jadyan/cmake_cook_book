In this recipe we use CMake to accommodate the conditional compilation of
source code that depends on the environment.
