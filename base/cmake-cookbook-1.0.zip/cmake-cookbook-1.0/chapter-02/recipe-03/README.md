# Dealing with compiler-dependent source code

In this recipe we use CMake to accommodate the conditional compilation of
source code that depends on the environment.


- [cxx-example](cxx-example/)
- [fortran-example](fortran-example/)
