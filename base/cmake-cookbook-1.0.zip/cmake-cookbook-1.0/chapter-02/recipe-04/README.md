# Discovering the host processor architecture

This recipe shows how to detect on which host processor architecture we are
building and which bit addressing is supported by the platform.


- [cxx-example](cxx-example/)
