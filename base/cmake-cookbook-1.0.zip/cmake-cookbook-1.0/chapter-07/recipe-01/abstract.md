This recipe will show how to use [functions] and [macros] in CMake and discuss
the differences between the two.

[functions]: https://cmake.org/cmake/help/latest/command/function.html#command:function
[macros]: https://cmake.org/cmake/help/latest/command/macro.html#command:macro
