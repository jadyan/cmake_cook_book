# Redefining functions and macros

This recipe shows how to redefine functions and macros. Our example will show
how to emulate the [`include_guard`] command, which is built-in since CMake
3.10, on systems running an older version of CMake.

[`include_guard`]: https://cmake.org/cmake/help/latest/command/include_guard.html


- [example](example/)
