# Writing a function to test and set compiler flags

Elaborating on [Recipe 7 in Chapter 5](../../chapter-05/recipe-07), we will show
how to write a function to test and set compiler flags for your project.


- [c-cxx-example](c-cxx-example/)
